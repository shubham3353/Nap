<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	public function isvalidate($email,$password)
	{
       $q=$this->db->where(['email'=>$email,'password'=>$password])->get('register');
        if($q->num_rows())
         {
            return $q->row()->id; // yeh id return karega
         }
         else
         {
             return false;
         }
	}

}
