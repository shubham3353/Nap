<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

	public function fetch_Assets()
	{
		$this->db->order_by("Assets","ASC");
		$q=$this->db->get('all_assets');
		return $q->result();
	}

	public function sub_Assets($assets_id)
	{
		  $this->db->where('assets_id', $assets_id);
		  $this->db->order_by('sub_assets', 'ASC');
		  $query = $this->db->get('sub_assets');
		  $output = '<option value="">Select Sub Assets</option>';
		  foreach($query->result() as $row)
		  {
		   $output .= '<option value="'.$row->sub_assets.'">'.$row->sub_assets.'</option>';
		  }
		  return $output;
	}

     public function all_Assets($all_id)
     {
     	 $this->db->where('assets_id', $all_id);
		  $this->db->order_by('sub_assets');
		  $query = $this->db->get('sub_assets');
		    $output = '<span id="heading"></span><tr class="row"><span class="second_id d-none">'.$all_id.'</span>';
		  foreach($query->result() as $row)
		  {
		   $output .= '<td class="col-md-3 sub_asset_name"  style="padding-left:44px;" value="'.$row->id.'">'.$row->sub_assets.'</td>
		                            <td class="col-md-1">10,000</td>
							        <td class="col-md-1 text-center">10,000</td>  
							        <td class="col-md-2 text-center">1,000,000,000</td>
							        <td class="col-md-1">10,000</td>
							        <td class="col-md-1">10,000,000</td>
							        <td class="col-md-1 text-center">10,000,000</td>
							        <td class="col-md-2 text-center">1,000,000,000</td>';
							        
		 
		  }
		  $output .=  '</tr>';
		  
		  return $output;
     }

     public function user_detail()
     {
     	$id=$this->session->userdata('id');
		$q=$this->db->select('*')->from('register')->where(['id'=>$id])->get();
		return $q->result();
     }

     	public function show_groups()
	{
	    $user_id=$this->session->userdata('id');
		$q=$this->db->select('*')->from('user_group')->where(['user_id'=>$user_id])->get();
		return $q->result();
	}
	   public function show_portfolio()
	{
	    $user_id=$this->session->userdata('id');
		$q=$this->db->select('*')->from('portfolio')->where(['user_id'=>$user_id])->get();
		return $q->result();
	}

	public function fetch_portfolio($group_name)
	{
       
		  $user_id=$this->session->userdata('id');
		  $this->db->where('port_group', $group_name);
		  $this->db->order_by('portfolio_name', 'ASC');
		   $query = $this->db->get('portfolio');

		   $afftectedRows=$this->db->affected_rows();
		   if($afftectedRows==0)
		   	{  $output="NO"; return $output;}
		   else{
		  foreach($query->result() as $row)
		  {
		    echo $output = '<a href="#" class="btn btn-success btn-sm">'.$row->portfolio_name.'</a>&nbsp;';
		  }
		 
		 
		  return $output;
		}
		
	}

	public function Dashboard_search($search_value)
	{
        $user_id=$this->session->userdata('id');
		$q=$this->db->select('*')->from('portfolio')->where(['user_id'=>$user_id])
		->like('portfolio_name', $search_value)->get();
		
		   $afftectedRows=$this->db->affected_rows();
		   if($afftectedRows==0)
		   	{  $output="NO"; return $output;}
		   else
		   {
				  foreach($q->result() as $row)
				  {
				    echo $output = '<a href="#" class="btn btn-success btn-sm">'.$row->portfolio_name.'</a>&nbsp;';
				  }
		 
		 
		  return $output;
	      }

   }


 public function type_stockname()
    {
    //   $this->db->select('*');
    //     $this->db->like('stock_name', $type_query);
    //     $query = $this->db->get("stock_details");       

		  // $this->db->order_by('stock_name', 'ASC');
		  //  $q = $this->db->get('stock_details'); 
   $q=$this->db->select('*')->order_by('stock_name','desc')->from('stock_details')->get();
		return $q->result();
    }

     public function type_broker()
    {        
   $q=$this->db->select('*')->order_by('broker_name','asc')->from('broker_details')->get();
		return $q->result();
    }
   
   	public function fetch_Mutualfund_name()
	{
		$this->db->order_by("mutual_fund_name","ASC");
		$q=$this->db->get('mutual_fund_name');
		return $q->result();
	}

	  public function mutual_scheme_name()
    {        
          $q=$this->db->select('*')->order_by('scheme_name','asc')->from('mutual_scheme')->get();
		return $q->result();
    }
       public function nps_scheme_name()
    {        
          $q=$this->db->select('*')->order_by('scheme_name','asc')->from('nps_scheme')->get();
		return $q->result();
    }

}
